package com.masai.exception;

public class InsufficientFundException extends Exception {
	
	public InsufficientFundException() {
		// TODO Auto-generated constructor stub
	}
	
	public InsufficientFundException(String message){
		super(message);
	}
	
}
