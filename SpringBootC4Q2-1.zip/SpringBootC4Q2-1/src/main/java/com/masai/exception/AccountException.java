package com.masai.exception;

public class AccountException extends Exception{
 
	public AccountException() {
		// TODO Auto-generated constructor stub
	}
	
	public AccountException(String message){
		super(message);
	}
}
