package com.masai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDay61ApplicationTests {

	@Test
	void contextLoads() {
	}

}
